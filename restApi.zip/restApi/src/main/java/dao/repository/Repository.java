package dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Cozinha;

public interface Repository extends JpaRepository<Cozinha, Integer> {

}
