package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cozinha")
public class Cozinha {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_cozinha;
	private String nome;
	private String chefeCozinha;

	
	
	
	public int getId_cozinha() {
		return id_cozinha;
	}
	public void setId_cozinha(int id_cozinha) {
		this.id_cozinha = id_cozinha;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getChefeCozinha() {
		return chefeCozinha;
	}
	public void setChefeCozinha(String chefeCozinha) {
		this.chefeCozinha = chefeCozinha;
	}
	
	

}
