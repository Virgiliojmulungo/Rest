import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import dao.repository.Repository;
import model.Cozinha;

@RestController

public class CozinhaController {

	@Autowired
	private Repository repository;
	
	@PostMapping("/cozinhas")
	@ResponseBody
	public Cozinha addCozinha() {
		Cozinha cozinha = new Cozinha();
		cozinha.setChefeCozinha("AAdda");
		cozinha.setNome("AAAAAAAAAAA");
		return repository.save(cozinha);
		
	}
	
	@GetMapping("/cozinhas")
	@ResponseBody
	public List<Cozinha> list(){
		return repository.findAll();
	}
}
